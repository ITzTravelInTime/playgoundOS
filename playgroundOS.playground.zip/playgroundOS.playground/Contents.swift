//: playgoundOS an OS inside a playground
import UIKit
import PlaygroundSupport

//: playground execution stars here


//: uncomment this line to use the apple logo instead of the pear logo (disabled for copyright reasons, keep it as is)
//pear = ""

//: set this to true to use a smaller fixed value for the view in the timeline, false uses the default dimension of the timeline window (a mac with an high resolution sceen is delivered)
mainView.forceFixedFrame = false

//: this line puts the view in playground mode, since the code is also designed to be used in a standard xcode project
mainView.runningOnPlaygooud = true

//: this line sets the shared instance of the main UIViewController, please do not modify this line or you will have some layout bugs and artefacts
currentView = mainView

//: sets the playgound live view to out main UIViewcontroller
PlaygroundPage.current.liveView = mainView.view

//: this playground needs infinite execution
PlaygroundPage.current.needsIndefiniteExecution = true
//: this line calls a function that fixes the frame of all the elements of the main UIViewController
mainView.resetUI()

