import Foundation
import UIKit

//shared variable and instances here
//public let mainView = ViewController()
public var currentView = ViewController()
public var currentWindow = ApplicationBar()
public var currentStripMenu = StripMenu()

public var pear = "🍐"

public let defaults = UserDefaults.standard
