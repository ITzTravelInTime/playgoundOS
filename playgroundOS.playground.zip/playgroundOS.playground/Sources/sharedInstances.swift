import Foundation
import UIKit

//shared variable and instances here
public var currentView = ViewController()
public let mainView = currentView
public var currentWindow = ApplicationBar()
public var currentStripMenu = StripMenu()

public var pear = "🍐"
