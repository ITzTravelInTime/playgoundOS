import Foundation
import UIKit

public class settings: ApplicationBar{
    let cardSize: CGFloat = 90
    var cards = [SettingsItem]()
    
    var card = SettingsItem()
    var code = SettingsItem()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        card = SettingsItem(name: "Playgound mode", details: "(if you are not running the code into a playgound)", price: 0.0, size: CGSize(width: self.view.frame.width, height: cardSize), target: self, selector: #selector(self.setPlaygoundMode(_:)))
        
        
        
        code = SettingsItem(name: "Fixed screen size mode ", details: "(use it if, on the main file of the playground, the mainView.forceFixedFrame is false)", price: 0.0, size: CGSize(width: self.view.frame.width, height: cardSize), target: self, selector: #selector(self.setFixedScreenMode(_:)))
        
        
        
        cards.append(card)
        cards.append(code)
        
        layout()
        
    }
    
    override public func viewDidLayoutSubviews() {
        layout()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        layout()
        
        card.switchItem.isOn = currentView.runningOnPlaygooud
        code.switchItem.isOn = currentView.forceFixedFrame
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        
    }
    
    func layout(){
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        
        var temp = CGPoint(x: 0, y: 40)
        for card in cards{
            card.frame.origin = temp
            card.frame.size = CGSize(width: self.view.frame.width, height: cardSize)
            
            card.updateCard()
            
            temp.y += cardSize + 1
            
            self.view.addSubview(card)
        }
        
        card.switchItem.isOn = currentView.runningOnPlaygooud
        code.switchItem.isOn = currentView.forceFixedFrame
    }
    
    @objc func setPlaygoundMode(_ sender: UISwitch){
        currentView.runningOnPlaygooud = sender.isOn
        currentView.resetUI()
    }

    @objc func setFixedScreenMode(_ sender: UISwitch)
    {
        currentView.forceFixedFrame = !sender.isOn
        currentView.resetUI()
    }
    
}

public class SettingsItem: UIView{
    public var nameLabel = UILabel()
    public var detailLabel = UILabel()
    public var switchItem = UISwitch()
    
    convenience init(name: String, details: String, price: Float, size: CGSize, target: Any, selector: Selector) {
        self.init(frame: CGRect())
        
        self.frame.size = size
        self.backgroundColor = .white
        
        /*self.imageView = UIImageView()
        
        self.imageView.frame.origin = CGPoint(x: 0, y: 0)
        
        self.imageView.frame.size = CGSize(width: self.frame.size.height, height: self.frame.size.height)
        
        self.imageView.contentMode = .scaleToFill
        
        self.imageView.image = image
        
        self.addSubview(self.imageView)
        */
 
        self.nameLabel = UILabel()
        
        self.nameLabel.frame.origin = CGPoint(x: 20, y: 0)
        self.nameLabel.frame.size = CGSize(width: self.frame.size.width - 20 - 80 - 10, height: 30)
        self.nameLabel.backgroundColor = .white
        self.nameLabel.textColor = .black
        self.nameLabel.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: 18)
        self.nameLabel.numberOfLines = 0
        self.nameLabel.text = name
        
        self.addSubview(self.nameLabel)
        
        self.detailLabel = UILabel()
        
        self.detailLabel.frame.origin = CGPoint(x: self.nameLabel.frame.origin.x, y: self.nameLabel.frame.height)
        self.detailLabel.frame.size = CGSize(width: self.nameLabel.frame.width, height: 60)
        
        self.detailLabel.backgroundColor = .white
        
        self.detailLabel.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: 12)
        self.detailLabel.numberOfLines = 0
        
        self.detailLabel.text = details
        
        self.addSubview(self.detailLabel)
        
        self.switchItem.frame.size = CGSize(width: 80, height: 30)
        self.switchItem.frame.origin = CGPoint(x: self.frame.width - self.switchItem.frame.width - 10, y: self.frame.size.height / 2 - self.switchItem.frame.size.height / 2)
        
        //self.buyButton.backgroundColor = UIColor(netHex: 0x3B99FC)
        //self.buyButton.setTitleColor(.white, for: .normal)
        //self.buyButton.layer.cornerRadius = 5
        
        //self.buyButton.setTitle("Installed", for: .normal)
        
        self.switchItem.addTarget(target, action: selector, for: .touchUpInside)
        self.addSubview(self.switchItem)
    }
    
    public func updateCard(){
        /*self.imageView.frame.origin = CGPoint(x: 0, y: 0)
        self.imageView.frame.size = CGSize(width: self.frame.size.height, height: self.frame.size.height)
        */
        
        
        self.nameLabel.frame.origin = CGPoint(x: 20, y: 0)
        self.nameLabel.frame.size = CGSize(width: self.frame.size.width - 20 - 80 - 10, height: 30)
        
        self.detailLabel.frame.origin = CGPoint(x: self.nameLabel.frame.origin.x, y: self.nameLabel.frame.height)
        self.detailLabel.frame.size = CGSize(width: self.nameLabel.frame.width, height: 60)
        
        self.switchItem.frame.size = CGSize(width: 80, height: 30)
        self.switchItem.frame.origin = CGPoint(x: self.frame.width - self.switchItem.frame.width - 10, y: self.frame.size.height / 2 - self.switchItem.frame.size.height / 2)
        
        
    }
}

