import Foundation
import UIKit
import WebKit

public class webBrowser: ApplicationBar{
    
    var web = UIWebView()
    var search = UITextField()
    var goButton = UIButton()
    
    var spamm = UIView()
    var im = UITextView()
    var procrastinate = UIButton()
    var close = UIButton()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubview(web)
        
        search.layer.cornerRadius = 5
        
        search.backgroundColor = .white
        
        search.textColor = .black
        
        search.text = "http://www.apple.com/"
        
        search.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        
        self.view.addSubview(search)
        
        goButton.layer.cornerRadius = search.layer.cornerRadius
        
        goButton.backgroundColor = .gray
        
        goButton.tintColor = .white
        
        goButton.setTitle("Go", for: .normal)
        
        goButton.addTarget(self, action: #selector(self.go), for: .touchUpInside)
        
        self.view.addSubview(goButton)
        
        spamm.backgroundColor = self.view.backgroundColor
        spamm.layer.cornerRadius = self.view.layer.cornerRadius
        
        close.backgroundColor = self.red.backgroundColor
        close.frame = self.red.frame
        close.layer.cornerRadius = self.red.layer.cornerRadius
        
        close.addTarget(self, action: #selector(self.closeSpamm(_:)), for: .touchUpInside)
        
        spamm.addSubview(close)
        
        procrastinate.layer.cornerRadius = goButton.layer.cornerRadius
        procrastinate.backgroundColor = goButton.backgroundColor
        
        procrastinate.tintColor = goButton.tintColor
        
        procrastinate.setTitle("Emergency procrastinate", for: .normal)
        
        procrastinate.addTarget(self, action: #selector(self.openProcrastination(_:)), for: .touchUpInside)
        
        spamm.addSubview(procrastinate)
        
        im.backgroundColor = spamm.backgroundColor
        
        im.textColor = .black
        im.text = "You can't go to the web because of the restrictions of this scolarship selection"
        
        im.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: 20)
        
        im.isEditable = false
        
        spamm.addSubview(im)
        
        red.addTarget(self, action: #selector(self.endEditingIM), for: .touchUpInside)
        orange.addTarget(self, action: #selector(self.endEditingIM), for: .touchUpInside)
        
        
    }
    
    override public func viewDidLayoutSubviews() {
        layout()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        layout()
        go()
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        im.endEditing(true)
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        im.endEditing(true)
    }
    
    func layout(){
        //web = UIWebView()
        
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        
        web.frame.origin = CGPoint(x: 0, y: 80)
        
        if isFullScreen == true{
            web.frame.size = CGSize(width: self.view.frame.width, height: self.view.frame.height - 80)
        }else{
            web.frame.size = CGSize(width: self.view.frame.width, height: self.view.frame.height - 80 - 10)
        }
        
        search.frame.origin = CGPoint(x: 10, y: 40)
        
        search.frame.size = CGSize(width: self.view.frame.width - 30 - 40, height: 30)
        
        goButton.frame.origin = CGPoint(x: search.frame.origin.x + search.frame.size.width + 10, y: search.frame.origin.y)
        goButton.frame.size = CGSize(width: 40, height:  search.frame.height)
        
        
        spamm.frame.origin = CGPoint(x: 40, y: 100)
        spamm.frame.size = CGSize(width: self.view.frame.width - 80, height: self.view.frame.height - 150)
        
        procrastinate.frame.origin = CGPoint(x: 20, y: spamm.frame.height - 40)
        procrastinate.frame.size = CGSize(width: spamm.frame.width - 40, height: 30)
        
        im.frame.origin = CGPoint(x: 0, y: 40)
        im.frame.size = CGSize(width: spamm.frame.size.width - 40, height: spamm.frame.size.height - 30 - 50)
        
    }
    
    @objc func go(){
        let u = URL(fileURLWithPath: search.text!)
        web.loadRequest(URLRequest(url: u))
        
        layout()
        
        UIView.animate(withDuration: 0.01, delay: 3, options: .curveEaseInOut, animations: {
            self.spamm.isHidden = false
            self.view.addSubview(self.spamm)
            
        }, completion: { finished in
            
        })
        
        endEditingIM()
    }
    
    @objc func closeSpamm(_ sender: UIButton){
        spamm.isHidden = true
        endEditingIM()
    }
    
    @objc func openProcrastination(_ sender: UIButton){
        //let frame = self.tempSize
        let associatedView = procatinateWindow()
        
        let parentController = currentView
        
        
        let fr = CGRect(x: 0, y: parentController.menuHeight + parentController.menuDistance + 7, width: Int(parentController.view.frame.width), height: Int(parentController.dock.frame.origin.y) - (parentController.menuHeight + parentController.menuDistance + 7) )
        
        
        associatedView.view.frame = fr
        
        associatedView.tempSize = fr
        
        parentController.showViewController(associatedView, fr)
        associatedView.setNormalScreen()
        associatedView.textLabel.text = "Emergency procrastination"
        associatedView.view.isHidden = false
        
        self.view.isHidden = true
        
        endEditingIM()
        
    }
    
    @objc func endEditingIM(){
        im.endEditing(true)
    }
}

