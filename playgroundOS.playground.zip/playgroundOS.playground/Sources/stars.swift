import Foundation
import UIKit
import SpriteKit

public class RainbowParticle : SKEmitterNode {
    init(guide: SKSpriteNode,childOf:SKNode,target:SKNode, color:SKColor, position:CGPoint){
        super.init()
        self.particleLifetime = 5
        self.particleBlendMode = SKBlendMode.alpha
        self.particleBirthRate = 25 * 5
        self.particleSpeed = 16 * 20
        self.emissionAngle = 3.14
        self.targetNode = target
        self.particleSize = CGSize(width: 35, height: 25)
        self.particleColor = color
        self.position = position
        childOf.addChild(self)
        //childOf.addChild(guide)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
