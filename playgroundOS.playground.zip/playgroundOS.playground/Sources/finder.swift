import Foundation
import UIKit

public class finder: ApplicationBar, UITableViewDataSource, UITableViewDelegate{
    
    public var search = UITextField()
    var goButton = UIButton()
    
    var fileTable = UITableView()
    
    var elemets = [String]()
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return elemets.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = fileTable.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = elemets[indexPath.item]
        
        print(elemets[indexPath.item])
        
        cell.imageView?.frame.size = CGSize(width: 80, height: 80)
        
        if elemets[indexPath.item] == "No windows here"{
            cell.imageView?.image = UIImage(named: "crash.jpg")
            print("the windows you are looking for is not here")
        }else{
            cell.imageView?.image = UIImage()
        }
        
        return cell
    }
    
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let frame = CGRect(x: 0, y: 80, width: self.view.frame.width, height: self.view.frame.height - 80 - 10)
        
        fileTable.frame = frame
        
        fileTable.delegate = self
        fileTable.dataSource = self
        
        fileTable.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        fileTable.backgroundColor = .white
        
        self.view.addSubview(fileTable)
        
        search.frame.origin = CGPoint(x: 10, y: 40)
        
        search.frame.size = CGSize(width: self.view.frame.width - 30 - 40, height: 30)
        
        search.layer.cornerRadius = 5
        
        search.backgroundColor = .white
        
        search.textColor = .black
        
        search.text = "C:\\Applications"
        
        search.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        
        self.view.addSubview(search)
        
        goButton.frame.origin = CGPoint(x: search.frame.origin.x + search.frame.size.width + 10, y: search.frame.origin.y)
        goButton.frame.size = CGSize(width: 40, height:  search.frame.height)
        
        goButton.layer.cornerRadius = search.layer.cornerRadius
        
        goButton.backgroundColor = .gray
        
        goButton.tintColor = .white
        
        goButton.setTitle("Go", for: .normal)
        
        goButton.addTarget(self, action: #selector(self.go), for: .touchUpInside)
        
        self.view.addSubview(goButton)
    }
    
    override public func viewDidLayoutSubviews() {
        layout()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        layout()
        go()
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        search.endEditing(true)
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch "\(elemets[indexPath.item])" {
        case "Procrastination":
            showView(newView: procatinateWindow(), title: "Procrastinate")
            break
        case "Code":
            showView(newView: FakePlayGrund(), title: "Code editor")
            break
        case "Web Browser":
            showView(newView: webBrowser(), title: "Browser")
            break
        case "Note":
            showView(newView: note(), title: "Note")
            break
        case "Store":
            showView(newView: store(), title: "Store")
            break
            case "Settings":
            showView(newView: settings(), title: "Settings")
            break
        case "Applications":
            elemets = ["Code", "procrastinate", "Web Browser", "Note","Store","Settings"]
            search.text = "C:\\Applications"
            fileTable.reloadData()
            break
        default:
            print("unknown")
            break
        }
        
        search.endEditing(true)
    }
    
    func showView(newView: ApplicationBar, title: String){
        let associatedView = newView
        
        let parentController = currentView
        
        
        let fr = CGRect(x: 0, y: parentController.menuHeight + parentController.menuDistance + 7, width: Int(parentController.view.frame.width), height: Int(parentController.dock.frame.origin.y) - (parentController.menuHeight + parentController.menuDistance + 7) )
        
        
        associatedView.view.frame = fr
        
        associatedView.tempSize = fr
        
        parentController.showViewController(associatedView, fr)
        associatedView.setNormalScreen()
        associatedView.textLabel.text = title
        associatedView.view.isHidden = false
        
        self.view.isHidden = true
        
        search.endEditing(true)
    }
    
    func layout(){
        var frame = CGRect(x: 0, y: 80, width: self.view.frame.width, height: self.view.frame.height - 80 - 10)
        
        if isFullScreen{
            frame.size.height += 10
        }
        
        fileTable.frame = frame
        
        search.frame.origin = CGPoint(x: 10, y: 40)
        
        search.frame.size = CGSize(width: self.view.frame.width - 30 - 40, height: 30)
        
        goButton.frame.origin = CGPoint(x: search.frame.origin.x + search.frame.size.width + 10, y: search.frame.origin.y)
        goButton.frame.size = CGSize(width: 40, height:  search.frame.height)
        
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
    }
    
    @objc func go(){
        search.endEditing(true)
        print("\(search.text!)".lowercased())
        
        
        switch "\(search.text!)".lowercased(){
        case "c:\\", "c:", "c:/", "/":
            elemets = ["Applications"]
            break
        case "c:\\applications", "c:/applications", "/applications":
            elemets = ["Procrastination", "Code", "Web Browser", "Note","Store","Settings"]
            break
        case "c:\\windows", "c:/windows", "/windows":
            elemets = ["No windows here"]
            break
        default:
            elemets = ["unknown directory"]
            break
        }
        print(elemets)
        
        fileTable.reloadData()
    }
    
}
