import Foundation
import UIKit

import JavaScriptCore

//Code editor windows class

public class FakePlayGrund: ApplicationBar, UITextViewDelegate{
    public let baseText = "//this code is used as library, please don't touch\n" +
        "let prints = \"\"\n" +
        "let Prints = prints\n" +
        "var print = function(text){prints += \"\\n\" + text;return prints}\n" +
        "var Print = function(args){return print(args)}" +
        "\n" +
        "//here will start the execution of the code by this program, don't touch\n" +
        "var execute = function(arguments)" +
        "{main(arguments);return prints;}\n\n\n" +
        "\n//please keep this function and start execute your code inside of it\n" +
        "var main = function(someArgs){\n\n" +
        "print(\"hello world\")" +
        "\n\n}\n\n\n" +
        "//put there here your code, like functions\n" +
        "// |  |  |  |  |  |  |  |  |  |  |  |  |  \n" +
        "// |  |  |  |  |  |  |  |  |  |  |  |  |  \n" +
        "// V  V  V  V  V  V  V  V  V  V  V  V  V  \n" +
        "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" +
    "//you are at the bottom of the page, go up for code"
    
    var console = UITextView()
    var ide = UITextView()//UITextField()
    var executeButton = UIButton()
    var checkButton = UIButton()
    var debugArea = UITextView()
    var debugLabel = UILabel()
    var procrastinateButton = UIButton()
    
    let debugAreaHeight: CGFloat = 200
    let labelHeight: CGFloat = 20
    
    var timer = Timer()
    
    let codeCommentColor = UIColor(netHex: 0x008400)
    let codeKeywordColor = UIColor(netHex: 0xC52CA2)
    let codeStringColor = UIColor(netHex: 0xD12F1B)
    let codeOperatorColor = UIColor(netHex: 0x3D1E81)
    
    override public func viewDidLoad(){
        super.viewDidLoad()
        ide.frame.origin = CGPoint(x: 0, y: 70)
        //ide.frame.size = CGSize(width: self.view.frame.width, height: self.view.frame.height - debugAreaHeight)
        
        ide.textColor = .black
        ide.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Menlo"))[2], size: (12))
        ide.textAlignment = .left
        ide.keyboardDismissMode = .onDrag
        ide.returnKeyType = .default
        
        ide.backgroundColor = .white
        
        ide.delegate = self
        
        ide.keyboardType = .default
        
        self.view.addSubview(ide)
        
        debugArea.frame.origin.x = 0
        debugArea.frame.origin.y = ide.frame.origin.y + ide.frame.size.height + labelHeight
        debugArea.frame.size.width = ide.frame.size.width
        debugArea.frame.size.height = self.view.frame.height - debugArea.frame.origin.y - 10
        //debugArea.numberOfLines = 0
        debugArea.isEditable = false
        debugArea.font = ide.font
        debugArea.backgroundColor = .white
        self.view.addSubview(debugArea)
        
        debugLabel.frame.origin.x = 0
        debugLabel.frame.origin.y = ide.frame.origin.y + ide.frame.size.height
        debugLabel.frame.size.width = ide.frame.size.width
        debugLabel.frame.size.height = labelHeight
        debugLabel.text = "Output: "
        debugLabel.textColor = .black
        self.view.addSubview(debugLabel)
        
        executeButton.frame.origin = CGPoint(x: 10, y: 35)
        executeButton.frame.size = CGSize(width: 80, height: 30)
        executeButton.backgroundColor = .lightGray
        executeButton.setTitle("Run", for: .normal)
        executeButton.layer.cornerRadius = 4
        
        executeButton.addTarget(self, action:
            #selector(self.runCode(_:)), for: .touchUpInside)
        
        self.view.addSubview(executeButton)
        
        checkButton.frame.origin = CGPoint(x: executeButton.frame.origin.x + executeButton.frame.size.width + 10,y: executeButton.frame.origin.y)
        
        checkButton.backgroundColor = executeButton.backgroundColor
        checkButton.frame.size = executeButton.frame.size
        checkButton.setTitle("Check", for: .normal)
        checkButton.layer.cornerRadius = executeButton.layer.cornerRadius
        
        checkButton.addTarget(self, action: #selector(self.checkCode(_:)), for: .touchUpInside)
        
        self.view.addSubview(checkButton)
        
        procrastinateButton.frame.origin = CGPoint(x: checkButton.frame.origin.x + checkButton.frame.size.width + 10,y: executeButton.frame.origin.y)
        procrastinateButton.frame.size = CGSize(width: executeButton.frame.size.width  + 60, height: executeButton.frame.size.height)
        procrastinateButton.backgroundColor = executeButton.backgroundColor
        procrastinateButton.setTitle("Procrastinate", for: .normal)
        procrastinateButton.layer.cornerRadius = executeButton.layer.cornerRadius
        procrastinateButton.addTarget(self, action: #selector(self.openProcrastination(_:)), for: .touchUpInside)
        
        self.view.addSubview(procrastinateButton)
        
        red.addTarget(self, action: #selector(self.close(_:)), for: .touchUpInside)
        orange.addTarget(self, action: #selector(self.minimize(_:)), for: .touchUpInside)
        //changeColors()
        //changeColorsLight()
        
        
        
    }
    
    @objc func close(_ sender: UIButton){
        ide.text = baseText
        changeColorsLight(start: 0, section: ide.text)
        ide.endEditing(true)
    }
    
    @objc func minimize(_ sender: UIButton){
        ide.endEditing(true)
    }
    
    @objc func openProcrastination(_ sender: UIButton){
        //let frame = self.tempSize
        let associatedView = procatinateWindow()
        
        let parentController = currentView
        
        
        let fr = CGRect(x: 0, y: parentController.menuHeight + parentController.menuDistance + 7, width: Int(parentController.view.frame.width), height: Int(parentController.dock.frame.origin.y) - (parentController.menuHeight + parentController.menuDistance + 7) )
        
        
        associatedView.view.frame = fr
        
        associatedView.tempSize = fr
        
        parentController.showViewController(associatedView, fr)
        associatedView.setNormalScreen()
        associatedView.textLabel.text = "Procrastinate"
        associatedView.view.isHidden = false
        
        self.view.isHidden = true
        
    }
    
    @objc func checkCode(_ sender: UIButton){
        ide.endEditing(true)
        var debugText = ""
        if ide.text != ""{
            let context = JSContext()
            let js = context?.evaluateScript(ide.text)
            let main = context?.objectForKeyedSubscript("execute")
            debugText += "Code checking:\n"
            if (js?.isUndefined == false && main?.isUndefined == false){
                print("invalid  core or sintax error")
                debugText += "syntax error in the code"
            }else{
                debugText += "your code is fine"
            }
            changeColorsLight(start: 0, section: ide.text)
        }else{
            debugText = "Please put code to be executed, and the needed function:\n var execute = function(arguments){\n/* code here*/\n}"
        }
        debugArea.text = debugText
        
    }
    
    var first = 0
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        if first > 10{
            UIView.animate(withDuration: 0.45, delay: 0, options: .curveEaseInOut, animations: {
                self.setIdeSize()
            }, completion: { finished in
                
            })
        }else{
            first += 1
            setIdeSize()
        }
        //executeButton.frame.size = CGSize(width: self.view.frame.width, height: 20)
        //textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin .x, height: 20)
    }
    
    func setIdeSize(){
        self.ide.frame.size = CGSize(width: self.view.frame.width, height: self.view.frame.height - self.debugAreaHeight)
        
        debugArea.frame.origin.y = ide.frame.origin.y + ide.frame.size.height + labelHeight
        debugArea.frame.size.width = ide.frame.size.width
        
        var delta: CGFloat = 10
        if isFullScreen{
            delta = 0
        }
        
        debugArea.frame.size.height = self.view.frame.height - debugArea.frame.origin.y - delta
        
        debugLabel.frame.origin.y = ide.frame.origin.y + ide.frame.size.height
        debugLabel.frame.size.width = ide.frame.size.width
    }
    
    public func textViewDidChange(_ textView: UITextView){
        /*if ide.text != baseText && ide.text != "" && ide.text != prec{
         
         }*/
    }
    
    var prec = ""
    
    @objc func tick(){
        if view.isHidden == false{
        if prec != ide.text {
            let dif = ide.text.characters.count - abs(prec.characters.count - ide.text.characters.count)
            //let section = self.ide.text.index(ide.text.endIndex, offsetBy: dif * -1)
            
            changeColorsLight(start: dif, section: ide.text.substring(to: self.ide.text.index(ide.text.endIndex, offsetBy: (dif * -1))))
            
            prec = ide.text
        }
        }else{
            timer.invalidate()
        }
    }
    
    public func textViewDidEndEditing(_ textView: UITextView){
        
    }
    
    var count = 0
    @objc func runCode(_ sender: UIButton){
        var debugText = ""
        ide.endEditing(true)
        if ide.text != ""{
            count += 1
            debugText = "execution \(count):\n"
            let context = JSContext()
            let _ = context?.evaluateScript(ide.text)
            let main = context?.objectForKeyedSubscript("execute")
            
            if let t = main?.call(withArguments: [""])!{
                print("execution number: \(count) executed successfully")
                print("\(t)")
                
                if "\(t)" != "undefined"{
                    debugText += "\(t)"
                }else{
                    debugText += "Syntax error, check your code"
                }
                
            }else{
                debugText += "needed function for code execution \"execute\" not found! \n Please create a function: \n var execute = function(arguments){\n/* code here*/\n}"
            }
        }else{
            debugText = "Please put code to be executed, and the needed function:\n var execute = function(arguments){\n/* code here*/\n}"
        }
        debugArea.text = debugText
        changeColorsLight(start: 0, section: ide.text)
    }
    let keywords = ["let","break","case","catch","continue","default","delete","do","else","finally","for","function","if","in","instanceof","new","return","switch","this","throw","try","typeof","var","void","while","with"]
    let reservedWorlds = ["abstract","boolean","byte","char","class","const","debugger","double","enum","export","extends","final","float","goto","int","interface","implements","import","long","native","package","private","protected","public","short","static","super","synchronized","throws","transient","volatile"]
    
    let separators = [" ", "\n", ";"]
    let pointing = ["{","}","(", ")", ".",",","[","]"]
    let operatros = ["+","-","/","*","%","=", "^"]
    let comments = ["//","/*"]
    
    var wordSeparators = [String]()
    
    var ct = 0
    @objc func changeColorsLight(start: Int, section: String){
        if wordSeparators == [String](){
            wordSeparators.append(contentsOf: separators)
            wordSeparators.append(contentsOf: pointing)
            wordSeparators.append(contentsOf: operatros)
        }
        ide.textColor = .black
        
        //UIView.animate(withDuration: 0.001, delay: 0, options: .curveEaseInOut, animations: {
        //DispatchQueue.main.async {
        
        var index = 0
        var stringRecording = false
        var commentRecording = false
        var stringStartIndex = 0
        var commentStartIndex = 0
        
        
        //var length = 0
        /*for c in (ide.text.characters.split { separators.contains(String($0)) }).map({ String($0).trimmingCharacters(in: .init()) }){
         }*/
        
        var tempValidCharactersString = ""
        var tempInvalidCharactersString = ""
        
        let lengthD = 0
        let startS = -1
        let startD = 0
        for c in self.ide.text.characters{
            index += 1
            let currentCharInString = String(c)
            
            if !self.wordSeparators.contains(currentCharInString){
                tempValidCharactersString += currentCharInString
                let ln = tempValidCharactersString.characters.count
                
                if ln == 1{
                    if currentCharInString == "\""{
                        if  !commentRecording{
                            if stringRecording{
                                self.changeTextPortionColor(start: stringStartIndex + startD, length: index - stringStartIndex + lengthD, color: self.codeStringColor)
                                stringRecording = false
                            }else{
                                stringStartIndex = index + startS
                                stringRecording = true
                            }
                        }
                    }
                }else{
                    if self.keywords.contains(tempValidCharactersString)  && stringRecording == false && commentRecording == false{
                        self.changeTextPortionColor(start: index - ln, length: ln, color: self.codeKeywordColor)
                    }
                    
                    if self.reservedWorlds.contains(tempValidCharactersString)  && stringRecording == false && commentRecording == false{
                        self.changeTextPortionColor(start: index - ln, length: ln, color: self.codeKeywordColor)
                    }
                    
                    if currentCharInString.characters.last == Character("\"") && commentRecording == false{
                        if stringRecording == true{
                            self.changeTextPortionColor(start: stringStartIndex + startD, length: index - stringStartIndex + lengthD, color: self.codeStringColor)
                            stringRecording = false
                        }else{
                            stringRecording = true
                            stringStartIndex = index + startS
                        }
                        
                    }
                    
                }
                tempInvalidCharactersString = ""
            }else{
                if self.operatros.contains(currentCharInString) && stringRecording == false && commentRecording == false{
                    self.changeTextPortionColor(start: index - 1, length: 1, color: self.codeOperatorColor)
                }
                
                if tempInvalidCharactersString.characters.count == 2{
                    tempInvalidCharactersString = "\(tempInvalidCharactersString.characters.last!)"
                }
                
                tempInvalidCharactersString += currentCharInString
                
                if (tempInvalidCharactersString == "//" || tempInvalidCharactersString == "/*") && stringRecording == false && commentRecording == false
                {
                    commentStartIndex = index
                    commentRecording = true
                }else if (commentRecording && (tempInvalidCharactersString == "*/" || currentCharInString == "\n" || index == self.ide.text.characters.count)){
                    
                    self.changeTextPortionColor(start: commentStartIndex - 2, length: index - commentStartIndex + 2, color: self.codeCommentColor)
                    commentRecording = false
                }
                
                tempValidCharactersString = ""
            }
            
            if (commentRecording && (index == self.ide.text.characters.count )){
                
                self.changeTextPortionColor(start: commentStartIndex - 2, length: index - commentStartIndex + 2, color: self.codeCommentColor)
                commentRecording = false
            }
        }
        self.ct += 1
        print("code cheched \(self.ct)")
        
        /*}, completion: { finished in
         
         })*/
        //}
    }
    
    
    func changeTextPortionColor(start: Int, length: Int, color: UIColor){
        //let ide = ide
        
        let range = ide.selectedRange
        
        /*var cPos = 0
         
         
         if let selectedRange = ide.selectedTextRange {
         
         cPos = ide.offset(from: ide.beginningOfDocument, to: selectedRange.start)
         
         }*/
        
        let string = NSMutableAttributedString(attributedString: ide.attributedText)
        
        string.addAttributes([NSForegroundColorAttributeName: color], range: NSRange.init(location: start, length: length))
        
        ide.attributedText = string
        
        ide.selectedRange = range
        
        
        /*if let newPosition = ide.position(from: ide.beginningOfDocument, offset: cPos) {
         
         ide.selectedTextRange = ide.textRange(from: newPosition, to: newPosition)
         }*/
        
    }
    
    override public func viewWillAppear(_ animated: Bool) {
        ide.text = baseText
        changeColorsLight(start: 0, section: ide.text)
        
        timer = Timer.scheduledTimer(timeInterval: 3, target:self, selector: #selector(FakePlayGrund.tick), userInfo: nil, repeats: true)
    }
}

