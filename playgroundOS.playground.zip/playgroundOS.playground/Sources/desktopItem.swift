import Foundation
import UIKit

//class for items like files in desktop
public class desktopItem: UIView{
    public var fileButton = ButtonItem()
    public var fileLabel = UILabel()
}
