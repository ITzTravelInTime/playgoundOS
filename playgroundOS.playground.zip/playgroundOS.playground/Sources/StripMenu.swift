import Foundation
import UIKit

public class StripMenu: UIVisualEffectView{
    private var items = [UIButton]()
    private var separators = [UIView]()
    
    public var itemsCollection: [UIButton]{
        set{
            items = newValue
        }
        get{
            return items
        }
    }
    
    public var separatorsCollection: [UIView]{
        set{
            separators = newValue
        }
        get{
            return separators
        }
    }
    
    var parent = UIView()
    
    private let buttonHeight = CGFloat(30)
    private let separatorHeight = CGFloat(1)
    private let margin = CGFloat(0)
    
    public let scroll = UIScrollView()
    public let scrollContentView = UIView()
    
    private var tempPoint = CGPoint(x: 0, y: 0)
    
    private let maxHeight: CGFloat = 250
    
    func addItem(_ text: String, _ target: Any?, _ selector: Selector) -> UIButton{
        
        if tempPoint.y >= (self.frame.height - buttonHeight) && self.frame.height < maxHeight{
            self.frame.size = CGSize(width: self.frame.width, height: self.frame.height + buttonHeight)
            
            scroll.frame.size = self.frame.size
            scroll.frame.origin = CGPoint.zero
            scroll.contentSize = scroll.frame.size
            
            scrollContentView.frame = scroll.frame
        }else if self.frame.height >= maxHeight{
            self.frame.size.height = maxHeight
            scroll.frame.size.height = maxHeight
            scroll.frame.origin = CGPoint.zero
            scroll.contentSize = CGSize(width: scroll.contentSize.width, height: scroll.contentSize.height + buttonHeight)
            
            scrollContentView.frame.origin = CGPoint.zero
            scrollContentView.frame.size = scroll.contentSize
        }
        
        let button = UIButton(frame: CGRect(x: tempPoint.x, y: tempPoint.y, width: self.frame.width - margin , height: buttonHeight))
        
        button.setTitle(text, for: .normal)
        button.setTitleColor(.black, for: .normal)
        
        button.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        
        button.contentHorizontalAlignment = .left
        
        button.addTarget(self, action: #selector(self.itempPressGeneric(_:)), for: .touchUpInside)
        button.addTarget(target, action: selector, for: .touchUpInside)
        
        tempPoint.y += buttonHeight
        
        items.append(button)
        //self.addSubview(button)
        
        self.scrollContentView.addSubview(button)
        return button
    }
    
    func addSeparator(){
        let separatorSpacing = 5
        
        if tempPoint.y >= (self.frame.height - buttonHeight) && self.frame.height < maxHeight{
            self.frame.size = CGSize(width: self.frame.width, height: self.frame.height + separatorHeight + CGFloat(separatorSpacing) * 2)
            
            scroll.frame.size = self.frame.size
            scroll.frame.origin = CGPoint.zero
            scroll.contentSize = scroll.frame.size
            
            scrollContentView.frame = scroll.frame
        }else if self.frame.height >= maxHeight{
            self.frame.size.height = maxHeight
            scroll.frame.size.height = maxHeight
            scroll.frame.origin = CGPoint.zero
            scroll.contentSize = CGSize(width: scroll.contentSize.width, height: scroll.contentSize.height + separatorHeight + CGFloat(separatorSpacing) * 2)
            
            scrollContentView.frame.origin = CGPoint.zero
            scrollContentView.frame.size = scroll.contentSize
        }
        
        let sepator = UIView(frame: CGRect(x: tempPoint.x - margin, y: tempPoint.y + CGFloat(separatorSpacing), width: self.frame.width, height: separatorHeight))
        
        sepator.backgroundColor = color.lightGray
        
        tempPoint.y += separatorHeight + CGFloat(separatorSpacing) * 2
        
        //self.addSubview(sepator)
        scrollContentView.addSubview(sepator)
    }
    
    func removeItem(_ index: Int){
        if !(items.count <= index || index < 0){
            self.willRemoveSubview(items[index])
        }
    }
    
    func removeSeparator(_ index: Int){
        if !(separators.count <= index || index < 0){
            self.willRemoveSubview(separators[index])
        }
    }
    
    
    func update(){
        for item in items{
            item.frame.size = CGSize(width: self.frame.width - margin, height: item.frame.height)
        }
        for separator in separators{
            separator.frame.size = CGSize(width: self.frame.width, height: separator.frame.height)
        }
        
        if tempPoint.y < maxHeight{
            self.frame.size.height = tempPoint.y
        }else{
            self.frame.size.height = maxHeight
        }
    }
    
    @objc func itempPressGeneric(_ sender: UIButton){
        self.isHidden = true
    }
    
    
}
