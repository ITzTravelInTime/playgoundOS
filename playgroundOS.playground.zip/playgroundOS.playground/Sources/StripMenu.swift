import Foundation
import UIKit

public class StripMenu: UIVisualEffectView{
    private var items = [UIButton]()
    private var separators = [UIView]()
    
    var itemsCollection: [UIButton]{
        set{
            items = newValue
        }
        get{
            return items
        }
    }
    
    var separatorsCollection: [UIView]{
        set{
            separators = newValue
        }
        get{
            return separators
        }
    }
    
    var parent = UIView()
    
    private let buttonHeight = CGFloat(30)
    private let separatorHeight = CGFloat(1)
    private let margin = CGFloat(20)
    
    private var tempPoint = CGPoint(x: 20, y: 0)
    
    func addItem(_ text: String, _ target: Any?, _ selector: Selector) -> UIButton{
        
        if tempPoint.y >= (self.frame.height - buttonHeight){
            self.frame.size = CGSize(width: self.frame.width, height: self.frame.height + buttonHeight)
        }
        
        let button = UIButton(frame: CGRect(x: tempPoint.x, y: tempPoint.y, width: self.frame.width - margin , height: buttonHeight))
        
        button.setTitle(text, for: .normal)
        button.setTitleColor(.black, for: .normal)
        
        button.contentHorizontalAlignment = .left
        
        button.addTarget(self, action: #selector(self.itempPressGeneric(_:)), for: .touchUpInside)
        button.addTarget(target, action: selector, for: .touchUpInside)
        
        tempPoint.y += buttonHeight
        
        items.append(button)
        self.addSubview(button)
        return button
    }
    
    func addSeparator(){
        let separatorSpacing = 5
        if tempPoint.y >= (self.frame.height - separatorHeight + CGFloat(separatorSpacing)){
            self.frame.size = CGSize(width: self.frame.width, height: self.frame.height + separatorHeight + CGFloat(separatorSpacing) * 2)
        }
        
        let sepator = UIView(frame: CGRect(x: tempPoint.x - margin, y: tempPoint.y + CGFloat(separatorSpacing), width: self.frame.width, height: separatorHeight))
        
        sepator.backgroundColor = color.lightGray
        
        tempPoint.y += separatorHeight + CGFloat(separatorSpacing) * 2
        
        self.addSubview(sepator)
    }
    
    func removeItem(_ index: Int){
        if !(items.count <= index || index < 0){
            self.willRemoveSubview(items[index])
        }
    }
    
    func removeSeparator(_ index: Int){
        if !(separators.count <= index || index < 0){
            self.willRemoveSubview(separators[index])
        }
    }
    
    
    func update(){
        for item in items{
            item.frame.size = CGSize(width: self.frame.width - margin, height: item.frame.height)
        }
        for separator in separators{
            separator.frame.size = CGSize(width: self.frame.width, height: separator.frame.height)
        }
        self.frame.size.height = tempPoint.y
    }
    
    @objc func itempPressGeneric(_ sender: UIButton){
        self.isHidden = true
    }
    
    
}
