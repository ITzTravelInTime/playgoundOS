import Foundation
import UIKit
import SpriteKit

public class procatinateWindow: ApplicationBar{

    let rainbowColors = [
        SKColor(red: 255/255, green: 43/255, blue: 14/255, alpha: 1),
        SKColor(red: 255/255, green: 168/255, blue: 6/255, alpha: 1),
        SKColor(red: 255/255, green: 244/255, blue: 5/255, alpha: 1),
        SKColor(red: 51/255, green: 234/255, blue: 5/255, alpha: 1),
        SKColor(red: 8/255, green: 163/255, blue: 255/255, alpha: 1),
        SKColor(red: 8122255, green: 85/255, blue: 255/255, alpha: 1),
        ]
    public var viewScene = SKView(frame: CGRect())
    public var scene = SKScene()
    
    var particles = [RainbowParticle]()
    var pearNode = SKSpriteNode()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
    }
    
    func rescene(){
        scene.removeAllChildren()
        
        let frame = CGSize(width: self.view.frame.width, height: self.view.frame.height - 200)
        let midPoint = CGPoint(x: frame.width / 2.0, y: frame.height / 2.0)
        
        let scale: CGFloat = 0.4
        
        scene = SKScene(size: frame)
        
        if pear != ""{
            pearNode = SKSpriteNode(imageNamed: "pear.png")
        }else{
            pearNode = SKSpriteNode(imageNamed: "apple.png")
        }
        pearNode.position = midPoint
        //nyanCat.setScale(8.0)
        pearNode.yScale = scale
        pearNode.xScale = scale
        
        let delta: CGFloat = 10
        let duration: Double = 0.25
        
        //action = SKAction.repeatForever(SKAction.sequence([SKAction.moveBy(x: 0, y: delta, duration: duration),SKAction.moveBy(x: 0, y: delta * -1, duration: duration)]))
        
        pearNode.run(SKAction.repeatForever(SKAction.sequence([
            SKAction.moveBy(x: 0, y: delta, duration: duration),
            SKAction.moveBy(x: 0, y: delta * -1, duration: duration)
            ])))
        
        pearNode.zPosition = 10
        
        let emitter = SKEmitterNode()
        emitter.particleLifetime = 40
        emitter.particleBlendMode = SKBlendMode.alpha
        emitter.particleBirthRate = 3
        emitter.particleSize = CGSize(width: 4,height: 4)
        emitter.particleColor = SKColor(red: 100, green: 100, blue: 255, alpha: 1)
        emitter.position = CGPoint(x:frame.width,y:midPoint.y)
        emitter.particleSpeed = 16
        emitter.particleSpeedRange = 100
        emitter.particlePositionRange = CGVector(dx: 0, dy: frame.height)
        emitter.emissionAngle = 3.14
        emitter.advanceSimulationTime(40)
        emitter.particleAlpha = 0.5
        emitter.particleAlphaRange = 0.5
        scene.addChild(emitter)
        
        var yMultiplier : CGFloat = 0.3
        for rainbowColor in rainbowColors{
            let particle = RainbowParticle(guide: pearNode,
                childOf: scene,
                target: pearNode,
                color: rainbowColor,
                position:
                CGPoint(
                    x: pearNode.calculateAccumulatedFrame().width * -0.3 + pearNode.position.x + 2,
                    y: pearNode.calculateAccumulatedFrame().height * yMultiplier + pearNode.position.y
                )
            )
            particles.append(particle)
            yMultiplier -= 0.10
        }
    
        scene.addChild(pearNode)
        
        
        self.viewScene.frame.origin.x  = 0//(self.view.frame.width / 2) - (self.viewScene.frame.width / 2)
        self.viewScene.frame.origin.y  = 40//(self.view.frame.height / 2) - (self.viewScene.frame.height / 2)
        
        viewScene = SKView(frame: CGRect(origin: viewScene.frame.origin, size: frame))
        viewScene.presentScene(scene)
        
        self.view.addSubview(viewScene)
    }
    
    override public func viewDidLayoutSubviews() {
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        rescene()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        rescene()
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        pearNode.isPaused = true
        pearNode.removeAllActions()
    
        for particle in particles{
            particle.isPaused = true
            particle.removeAllActions()
        }
    }
    

}
