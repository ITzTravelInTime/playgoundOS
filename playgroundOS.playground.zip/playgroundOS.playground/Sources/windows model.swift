import Foundation
import UIKit

public class windowModel: ApplicationBar{
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override public func viewDidLayoutSubviews() {
        layout()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        layout()
        
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        
    }
    
    func layout(){
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        
    }
}
