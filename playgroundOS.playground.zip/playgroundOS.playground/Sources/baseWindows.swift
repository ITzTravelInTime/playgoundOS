import Foundation
import UIKit

//basic windows class
public class ApplicationBar: UIViewController{
    var red = UIButton()
    var orange = UIButton()
    var green = UIButton()
    
    var distance = CGFloat(0)
    
    public var textLabel = UILabel()
    
    let size = 20
    let radius: CGFloat = 7
    
    var tempSize = CGRect()
    public var isFullScreen = false
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        tempSize = self.view.frame
        
        //self.textLabel.text = "finestra!"
        distance = CGFloat(currentView.menuDistance)
        
        self.view.backgroundColor = UIColor(netHex: 0xE6E6E6)
        
        self.view.layer.cornerRadius = radius
        
        red.frame = CGRect(x: 10, y: 7, width: size, height: size)
        red.backgroundColor = UIColor(netHex: 0xFF5F58)
        red.layer.cornerRadius = CGFloat(size / 2)
        red.addTarget(self, action: #selector(self.redPress(_:)), for: .touchUpInside)
        self.view.addSubview(red)
        
        orange.frame = red.frame
        orange.frame.origin.x += CGFloat(7 + size)
        orange.layer.cornerRadius = red.layer.cornerRadius
        orange.backgroundColor = UIColor(netHex: 0xFFBD2E)
        orange.addTarget(self, action: #selector(self.orangePress(_:)), for: .touchUpInside)
        self.view.addSubview(orange)
        
        green.frame = orange.frame
        green.frame.origin.x += CGFloat(7 + size)
        green.layer.cornerRadius = red.layer.cornerRadius
        green.backgroundColor = UIColor(netHex: 0x28C941)
        green.addTarget(self, action: #selector(self.greenPress(_:)), for: .touchUpInside)
        self.view.addSubview(green)
        
        //textLabel.frame.origin = green.frame.origin
        //textLabel.frame.origin.x += CGFloat(7 + size)
        
        textLabel.frame.origin = CGPoint.zero
        textLabel.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: (16))
        textLabel.textAlignment = .center
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin .x, height: 20)
        textLabel.textColor = .black
        
        self.view.addSubview(textLabel)
        
    }
    
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        currentWindow.view.isHidden = true
        currentWindow = self
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        
        currentStripMenu.hide()
    }
    
    @objc public func redPress(_ sender: UIButton){
        currentStripMenu.hide()
        self.view.isHidden = true
        self.dismiss(animated: true, completion: {})
    }
    
    @objc func orangePress(_ sender: UIButton){
        currentStripMenu.hide()
        self.view.isHidden = true
    }
    
    public  func setFullScreen(){
        currentStripMenu.hide()
        isFullScreen = !true
        changeScreenMode()
    }
    
    public func setNormalScreen(){
        currentStripMenu.hide()
        isFullScreen = !false
        changeScreenMode()
    }
    
    @objc func greenPress(_ sender: UIButton){
        currentStripMenu.hide()
        changeScreenMode()
    }
    
    func changeScreenMode(){
        currentStripMenu.hide()
        distance = CGFloat(currentView.menuDistance)
        if isFullScreen == false{
            UIView.animate(withDuration: 0.45, delay: 0, options: .curveEaseInOut, animations: {
                self.tempSize = self.view.frame
                self.view.frame.origin = CGPoint(x: 0, y: self.distance)
                
                self.view.frame.size = CGSize(width: (self.view.superview?.frame.size.width)!, height: (self.view.superview?.frame.size.height)! - self.distance)
                
            }, completion: { finished in
                
            })
            self.view.layer.cornerRadius = 0
            isFullScreen = true
        }else{
            UIView.animate(withDuration: 0.45, delay: 0, options: .curveEaseInOut, animations: {
                self.view.frame = self.tempSize
            }, completion: { finished in
                
            })
            
            isFullScreen = false
            self.view.layer.cornerRadius = radius
        }
    }
}
