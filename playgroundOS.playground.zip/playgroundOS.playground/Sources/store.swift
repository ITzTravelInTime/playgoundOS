import Foundation
import UIKit

public class store: ApplicationBar{
    let cardSize: CGFloat = 60
    var cards = [storeItem]()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let card = storeItem(name: "Procrastinator", image: UIImage(named: "pear.png")!, price: 0.0, size: CGSize(width: self.view.frame.width, height: cardSize), target: self, selector: #selector(self.proc))
        
        let code = storeItem(name: "Code (coding tool)", image: UIImage(named: "Code.png")!, price: 0.0, size: CGSize(width: self.view.frame.width, height: cardSize), target: self, selector: #selector(self.codeing))
        
        cards.append(card)
        cards.append(code)
        
        layout()
    }
    
    override public func viewDidLayoutSubviews() {
        layout()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        layout()
        
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        
    }
    
    func layout(){
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        
        var temp = CGPoint(x: 0, y: 40)
        for card in cards{
            card.frame.origin = temp
            card.frame.size = CGSize(width: self.view.frame.width, height: cardSize)
            
            card.updateCard()
            
            temp.y += cardSize + 1
            
            self.view.addSubview(card)
        }
    }
    
    @objc func proc(){
        let associatedView = procatinateWindow()
        
        let parentController = currentView
        
        
        let fr = CGRect(x: 0, y: parentController.menuHeight + parentController.menuDistance + 7, width: Int(parentController.view.frame.width), height: Int(parentController.dock.frame.origin.y) - (parentController.menuHeight + parentController.menuDistance + 7) )
        
        
        associatedView.view.frame = fr
        
        associatedView.tempSize = fr
        
        parentController.showViewController(associatedView, fr)
        associatedView.setNormalScreen()
        associatedView.textLabel.text = "Procrastinator"
        associatedView.view.isHidden = false
        
        self.view.isHidden = true
    }
    
    @objc func codeing(){
        let associatedView = FakePlayGrund()
        
        let parentController = currentView
        
        
        let fr = CGRect(x: 0, y: parentController.menuHeight + parentController.menuDistance + 7, width: Int(parentController.view.frame.width), height: Int(parentController.dock.frame.origin.y) - (parentController.menuHeight + parentController.menuDistance + 7) )
        
        
        associatedView.view.frame = fr
        
        associatedView.tempSize = fr
        
        parentController.showViewController(associatedView, fr)
        associatedView.setNormalScreen()
        associatedView.textLabel.text = "Code"
        associatedView.view.isHidden = false
        
        self.view.isHidden = true
    }
}

public class storeItem: UIView{
    public var imageView = UIImageView()
    public var nameLabel = UILabel()
    public var buyButton = UIButton()
    
    convenience init(name: String, image: UIImage, price: Float, size: CGSize, target: Any, selector: Selector) {
        self.init(frame: CGRect())
        
        self.frame.size = size
        self.backgroundColor = .white
        
        self.imageView = UIImageView()
        
        self.imageView.frame.origin = CGPoint(x: 5, y: 5)
        self.imageView.frame.size = CGSize(width: self.frame.size.height - 10, height: self.frame.size.height - 10)
        
        self.imageView.contentMode = .scaleToFill
        
        self.imageView.image = image

        self.addSubview(self.imageView)
        
        self.nameLabel = UILabel()
        
        self.nameLabel.frame.origin = CGPoint(x: self.frame.height, y: 0)
        self.nameLabel.frame.size = CGSize(width: self.frame.size.width - self.frame.size.height, height: 30)
        self.nameLabel.backgroundColor = .white
        self.nameLabel.textColor = .black
        self.nameLabel.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: 20)
        self.nameLabel.text = name
        
        self.addSubview(self.nameLabel)
        
        self.buyButton.frame.size = CGSize(width: 80, height: 30)
        self.buyButton.frame.origin = CGPoint(x: self.frame.width - self.buyButton.frame.width - 10, y: self.frame.size.height / 2 - self.buyButton.frame.size.height / 2)
        
        self.buyButton.backgroundColor = UIColor(netHex: 0x3B99FC)
        self.buyButton.setTitleColor(.white, for: .normal)
        self.buyButton.layer.cornerRadius = 5
        
        self.buyButton.setTitle("Installed", for: .normal)
        
        self.buyButton.addTarget(target, action: selector, for: .touchUpInside)
        self.addSubview(self.buyButton)
    }
    
    public func updateCard(){
        self.imageView.frame.origin = CGPoint(x: 5, y: 5)
        self.imageView.frame.size = CGSize(width: self.frame.size.height - 10, height: self.frame.size.height - 10)
        
        self.nameLabel.frame.origin = CGPoint(x: self.frame.height, y: 0)
        self.nameLabel.frame.size = CGSize(width: self.frame.size.width - self.frame.size.height, height: 30)
        
        self.buyButton.frame.size = CGSize(width: 80, height: 30)
        self.buyButton.frame.origin = CGPoint(x: self.frame.width - self.buyButton.frame.width - 10, y: self.frame.size.height / 2 - self.buyButton.frame.size.height / 2)
        
        
    }
}


