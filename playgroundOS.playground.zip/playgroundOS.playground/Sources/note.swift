import Foundation
import UIKit

public class note: ApplicationBar, UITextViewDelegate{
    
    var send = UIButton()
    var boringNotes = UIButton()
    var crazyText = UITextView()
    
    var spamm = UIView()
    var im = UITextView()
    var procrastinate = UIButton()
    var close = UIButton()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        crazyText.delegate = self
        
        crazyText.textColor = .black
        crazyText.backgroundColor = UIColor(netHex: 0xF8F8F6)//.white
        
        crazyText.text = "Enjoy the crazy notes"
        
        crazyText.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: (20))
        
        crazyText.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        
        self.view.addSubview(crazyText)
        
        boringNotes.backgroundColor = .gray
        boringNotes.tintColor = .white
        boringNotes.setTitle("Notes are boring", for: .normal)
        boringNotes.layer.cornerRadius = 5
        
        self.view.addSubview(boringNotes)
        
        send.backgroundColor = boringNotes.backgroundColor
        send.tintColor = boringNotes.tintColor
        
        send.setTitle("Share", for: .normal)
        send.layer.cornerRadius = boringNotes.layer.cornerRadius
        
        send.addTarget(self, action: #selector(self.share), for: .touchUpInside)
        
        self.view.addSubview(send)
        
        spamm.isHidden = true
        
        spamm.backgroundColor = self.view.backgroundColor
        spamm.layer.cornerRadius = self.view.layer.cornerRadius
        
        close.backgroundColor = self.red.backgroundColor
        close.frame = self.red.frame
        close.layer.cornerRadius = self.red.layer.cornerRadius
        
        close.addTarget(self, action: #selector(self.closeSpamm(_:)), for: .touchUpInside)
        
        spamm.addSubview(close)
        
        procrastinate.layer.cornerRadius = boringNotes.layer.cornerRadius
        procrastinate.backgroundColor = boringNotes.backgroundColor
        
        procrastinate.tintColor = boringNotes.tintColor
        
        procrastinate.setTitle("Share with the procrastinator friend", for: .normal)
        
        procrastinate.titleLabel?.numberOfLines = 0
        
        procrastinate.addTarget(self, action: #selector(self.openProcrastination(_:)), for: .touchUpInside)
        
        spamm.addSubview(procrastinate)
        
        im.backgroundColor = spamm.backgroundColor
        
        im.textColor = .black
        im.text = "Select a friend to share whith him this amazing note!"
        
        im.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: 20)
        
        im.isEditable = false
        
        spamm.addSubview(im)

        
        red.addTarget(self, action: #selector(self.exitEditing), for: .touchUpInside)
        orange.addTarget(self, action: #selector(self.exitEditing), for: .touchUpInside)
    }
    
    override public func viewDidLayoutSubviews() {
        layout()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        layout()
        
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        
    }
    
    public func textViewDidChange(_ textView: UITextView){
        if self.view.isHidden == false{
        let name = (UIFont.fontNames(forFamilyName: "Helvetica"))
        
        crazyText.font = UIFont(name: name[Int(arc4random_uniform(UInt32(Int(name.count - 1))))], size: 20)!
        }
    }
    
    func layout(){
        textLabel.frame.size = CGSize(width: (self.view?.frame.size.width)! - textLabel.frame.origin.x, height: 20)
        
        crazyText.frame.origin = CGPoint(x: 0, y: 80)
        
        if !isFullScreen{
        crazyText.frame.size = CGSize(width: self.view.frame.width, height: self.view.frame.height - 80 - 10)
        }else{
            crazyText.frame.size = CGSize(width: self.view.frame.width, height: self.view.frame.height - 80)
        }
        
        boringNotes.frame.origin = CGPoint(x: 10, y: 40)
        boringNotes.frame.size = CGSize(width: self.view.frame.width - 20 - 10 - 80, height: 30)
        
        boringNotes.isHidden = true
        
        send.frame.origin = CGPoint(x: boringNotes.frame.origin.x + boringNotes.frame.size.width + 10, y: boringNotes.frame.origin.y)
        
        send.frame.size = CGSize(width: 80, height: boringNotes.frame.size.height)
        
        spamm.frame.origin = CGPoint(x: 40, y: 100)
        spamm.frame.size = CGSize(width: self.view.frame.width - 80, height: self.view.frame.height - 150)
        
        im.frame.origin = CGPoint(x: 20, y: 40)
        im.frame.size = CGSize(width: spamm.frame.size.width - 40, height: 60)
        
        procrastinate.frame.origin = CGPoint(x: 20, y: im.frame.origin.y + im.frame.height + 20)
        procrastinate.frame.size = CGSize(width: spamm.frame.width - 40, height: 60)
        
    }
    
    @objc func closeSpamm(_ sender: UIButton){
        spamm.isHidden = true
    }
    
    @objc func exitEditing(){
        crazyText.endEditing(true)
    }
    
    @objc func share(){
        exitEditing()
        
        
        
        self.view.addSubview(spamm)
        spamm.isHidden = false
    }
    
    @objc func openProcrastination(_ sender: UIButton){
        //let frame = self.tempSize
        exitEditing()
        
        let associatedView = procatinateWindow()
        
        let parentController = currentView
        
        
        let fr = CGRect(x: 0, y: parentController.menuHeight + parentController.menuDistance + 7, width: Int(parentController.view.frame.width), height: Int(parentController.dock.frame.origin.y) - (parentController.menuHeight + parentController.menuDistance + 7) )
        
        
        associatedView.view.frame = fr
        
        associatedView.tempSize = fr
        
        parentController.showViewController(associatedView, fr)
        
        
        associatedView.textLabel.text = "procrastinator friend"
        associatedView.view.isHidden = false
        
        //self.view.isHidden = true
        
        if !self.isFullScreen {
            associatedView.setNormalScreen()
        }else{
            associatedView.setFullScreen()
        }
        
        spamm.isHidden = true
        
    }
}
