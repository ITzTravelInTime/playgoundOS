import Foundation
import UIKit

public class menuButton: UIButton{
    var associated: StripMenu!
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        if let asc = associated{
            if currentStripMenu != asc{
                currentStripMenu.isHidden = true
                currentStripMenu = asc
            }
            if asc.isHidden == true{
                asc.isHidden = false
                asc.frame.origin.x = self.frame.origin.x
                asc.frame.origin.y = (self.superview?.frame.height)! + 1
                self.superview?.superview?.addSubview(associated)
                asc.update()
            }else{
                asc.isHidden = true
            }
        }
    }
}
