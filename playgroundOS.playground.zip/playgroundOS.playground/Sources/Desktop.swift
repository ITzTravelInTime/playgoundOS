import Foundation
import UIKit

//Desktop ***********************************
 public class ViewController: UIViewController{
    /**Use it to force the desktop to be loaded to a fixed size (if you try to red from it it will always return false)*/
    public var forceFixedFrame: Bool {
        set{
            if newValue == true{
            self.view.frame = CGRect(x: 0, y: 0, width: 375, height: 600)
            //currentView.onPlaygound = newValue
            }else{
                let screenSize: CGRect = UIScreen.main.bounds
                self.view.frame = screenSize
            }
            self.resetUI()
        }
        get{
            return false
        }
    }
    
    public var runningOnPlaygooud: Bool{
        set{
            onPlaygound = newValue
            checkDistance()
            setCurrentView()
        }
        get{
            return onPlaygound
        }
    }
    
    private var onPlaygound = false
    
    var alreadyAdded: Bool = false
    
    let background = UIImageView(frame: CGRect.zero)
    let recognizer = UITapGestureRecognizer()
    
    let blurs = [UIBlurEffect(style: UIBlurEffectStyle.light),UIBlurEffect(style: UIBlurEffectStyle.extraLight)]
    
    public var menu = UIVisualEffectView()
    public let menuHeight = 26
    public var menuDistance = 0
    
    public var needsRecalc = false
    
    let menuBlu: UIColor = UIColor(netHex: 0x0B6EDF)
    var buttons = [menuButton]()
    
    var mela = menuButton()
    
    public var dock = UIVisualEffectView()
    var iconSide = Int()
    var iconCollection = [ButtonItem]()
    let alpha = CGFloat(0.8)
    let spacing = 7
    
    var files = [UIView]()
    
    
    func createIcon(_ image: UIImage,_ name: String)-> ButtonItem{
        let icon = ButtonItem(frame: CGRect(x: 0, y: 0, width: iconSide, height: iconSide))
        icon.titleLabel?.text = name
        icon.titleLabel?.isHidden = true
        
        icon.setBackgroundImage(image, for: .normal)//.image = image
        icon.imageView?.image = image
        
        icon.parentController = self
        
        //icon.associatedViewFrame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7) )
        
        icon.imageView?.contentMode = .scaleAspectFit
        
        icon.addTarget(self, action: #selector(self.dockItemOpening(_:)), for: .touchUpInside)
        
        //icon.backgroundColor = .red
        
        iconCollection.append(icon)
        
        return icon
    }
    
    func createFile(_ image: UIImage,_ name: String)->desktopItem{
        let fileView = desktopItem(frame: CGRect(x: 0, y: 0, width: iconSide + 20, height: iconSide + 20 + 20))
        
        //fileView.backgroundColor = .red
        
        
        fileView.fileButton = ButtonItem(frame: CGRect(x:0, y:0, width: iconSide + 20, height: iconSide + 20))
        let fileButton = fileView.fileButton
        
        fileButton.setBackgroundImage(image, for: .normal)
        
        //fileButton.backgroundColor = .green
        
        fileButton.imageView?.contentMode = .scaleAspectFit
        
        fileButton.titleLabel?.text = name
        
        fileButton.parentController = self
        
        //fileButton.associatedViewFrame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7) )
        
        
        
        fileView.fileLabel = UILabel(frame: CGRect(x: 0, y: iconSide + 20, width: iconSide + 20, height: 20))
        
        let labelName = fileView.fileLabel
        labelName.text = name
        
        //labelName.backgroundColor = .blue
        
        labelName.textColor = .white
        
        labelName.textAlignment = .center
        
        labelName.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[0], size: (labelName.font.pointSize))
        
        labelName.shadowColor = .gray
        
        fileView.addSubview(fileButton)
        fileView.addSubview(labelName)
        
        //fileView.addSubview(labelName)
        
        files.append((fileView))
        
        return fileView
        
        
    }
    
    func getDock()-> UIVisualEffectView{
        let margin = 20
        let height = 75
        let radious = 7
        let dockpos = Int(self.view.frame.height) - height + radious + 5
        
        let offset = height - 23 + spacing
        
        dock = UIVisualEffectView(effect: blurs[0])
        
        //dock.frame = CGRect(x: Int(margin / 2), y: dockpos, width: Int(self.view.frame.width) - margin ,height: height)
        
        var width = CGFloat(offset * iconCollection.count)
        
        while width >= self.view.frame.width - CGFloat(margin) {
            width -= CGFloat(offset)
        }
        
        dock.frame.size = CGSize(width: Int(width), height: height)

        dock.frame.origin = CGPoint(x: Int(self.view.frame.size.width - width) / 2, y: dockpos)
        
        dock.layer.cornerRadius = CGFloat(radious)
        dock.contentView.layer.cornerRadius = CGFloat(radious)
        
        dock.clipsToBounds = true
        
        //dock.layer.shadowColor = UIColor.gray.cgColor
        
        //dock.backgroundColor = UIColor.gray.withAlphaComponent(alpha)
        
        dock.isOpaque = true
        
        return dock
    }
    
    func getMenu(_ associatedButton: menuButton)->StripMenu{
        
        let menu = StripMenu(effect: blurs[1])
        if (menu.frame.origin.x + menu.frame.size.width) >= self.view.frame.size.width {
            menu.frame.origin.x = self.view.frame.width - menu.frame.width
        }
        
        menu.frame = CGRect(x: Int(associatedButton.frame.origin.x), y: Int(self.menuHeight + 1 + menuDistance), width: 300, height: 10)
        
        //menu.backgroundColor = color.white.withAlphaComponent(alpha)
        
        associatedButton.associated = menu
        
        menu.layer.cornerRadius = 5
        
        menu.contentView.layer.cornerRadius = 5
        
        menu.clipsToBounds = true
        
        menu.isHidden = true
        
        menu.scroll.frame.size = menu.frame.size
        menu.scrollContentView.frame.size = menu.frame.size
        
        menu.scroll.frame.origin = CGPoint.zero
        menu.scrollContentView.frame.origin = CGPoint.zero
        
        menu.scroll.isUserInteractionEnabled = true
        menu.scrollContentView.isUserInteractionEnabled = true
        
        menu.addSubview(menu.scroll)
        menu.scroll.addSubview(menu.scrollContentView)
        
        self.view.addSubview(menu)
        
        return menu
    }
    
    func createButton(_ text: String) -> menuButton{
        let menuButtonItem = menuButton(frame: CGRect(x: 0, y: 0,width: 100,height: menuHeight))
        
        menuButtonItem.setTitleColor(.black, for: .normal)
        menuButtonItem.titleLabel?.textAlignment = .center
        menuButtonItem.setTitle(text, for: .normal)
        
        //newLabel.backgroundColor = .red
        
        menuButtonItem.frame.size = CGSize(width: (12 * (menuButtonItem.titleLabel?.text?.characters.count)!), height: menuHeight)
        
        menuButtonItem.addTarget(self, action: #selector(self.menuButtonDidPress(_:)), for: .touchDown)
        menuButtonItem.addTarget(self, action: #selector(self.menuButtonDidPress(_:)), for: .touchDragEnter)
        menuButtonItem.addTarget(self, action: #selector(self.menuButtonDidUnpress(_:)), for: .touchDragExit)
        menuButtonItem.addTarget(self, action: #selector(self.menuButtonDidUnpress(_:)), for: .touchUpInside)
        
        buttons.append(menuButtonItem)
        
        return menuButtonItem
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        if let p = defaults.string(forKey: "pear"){
            pear = p
        }
        
        //pear = ""
        
        currentView = self
        
        background.backgroundColor = .gray
        
        background.contentMode = .scaleAspectFill
        
        background.isUserInteractionEnabled = true
        recognizer.addTarget(self, action: #selector(ViewController.profileImageHasBeenTapped))
        background.addGestureRecognizer(recognizer)
        
        mela = createButton(pear)//("")
        mela.frame.size = CGSize(width: 35, height: menuHeight)
        mela.addTarget(self, action: #selector(self.melaMenuClick), for: .touchUpInside)
        let melaMenu = getMenu(mela)
        let _ = melaMenu.addItem("About this playgound", self, #selector(self.info(_:)))
        let _ = melaMenu.addSeparator()
        let _ = melaMenu.addItem("Procrastination", self, #selector(self.procrastinate(_:)))
        
        
        let playgroundMenu = createButton("Playground")
        let pm = getMenu(playgroundMenu)
        let _ = pm.addItem("Preferences...", self, #selector(self.openSettings))
        let _ = pm.addSeparator()
        let _ = pm.addItem("File Explorer", self, #selector(self.showFinder))
        let _ = pm.addItem("Web browser", self, #selector(self.openSafari))
        let _ = pm.addItem("Note", self, #selector(self.openNote))
        let _ = pm.addItem("Store", self, #selector(self.openStore))
        let _ = pm.addSeparator()
        let _ = pm.addItem("Code", self, #selector(self.openCode))
        
        /*for _ in 0...2{
            let _ = pm.addItem("Preferences...", self, #selector(self.openSettings))
            let _ = pm.addSeparator()
            let _ = pm.addItem("File Explorer", self, #selector(self.showFinder))
            let _ = pm.addItem("Web browser", self, #selector(self.openSafari))
            let _ = pm.addItem("Note", self, #selector(self.openNote))
            let _ = pm.addItem("Store", self, #selector(self.openStore))
            let _ = pm.addSeparator()
            let _ = pm.addItem("Code", self, #selector(self.openCode))
        }*/
        
        playgroundMenu.titleLabel?.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[0], size: (playgroundMenu.titleLabel?.font.pointSize)!)
        
        let file = createButton("File")
        let files = getMenu(file)
        let _ = files.addItem("/Applications", self, #selector(self.openApps))
        //let _ = files.addItem("/", self, #selector(self.openRoot))
        
        //resetUI()
        
        checkDistance()
    }
    
    public func showViewController(_ controller: UIViewController, _ controllerFrame: CGRect){
        
        let view = controller.view
        
        view?.frame = controllerFrame
        view?.isUserInteractionEnabled = true
        
        self.addChildViewController(controller)
        self.view.addSubview(controller.view)
        controller.didMove(toParentViewController: self)
        
    }
    
    public func resetUI(){
        let subViews = self.view.subviews
        for subview in subViews{
            if subview != dock && subview != menu && subview != background {
            subview.removeFromSuperview()
            }
        }
        
        setCurrentView()
        
        background.frame = self.view.frame
        
        if pear == ""{
            background.image = UIImage(named: "backgroundApple.jpg")!
        }else{
            background.image = UIImage(named: "background.jpg")!
        }
        
        menu = UIVisualEffectView(effect: blurs[1])
        
        menu.frame = CGRect(x: 0, y: 0,width: Int(background.frame.width),height: menuHeight + menuDistance)
        
        //menu.backgroundColor = UIColor.white.withAlphaComponent(alpha)
        
        //dock = getDock()
        //iconSide = Int(dock.frame.height) - 25

        
        if alreadyAdded == false{
            
            iconCollection.removeAll()
            files.removeAll()
            
        let frame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7))
            
            var fileExplorerIcon = UIImage(named: "finder.png")!
            var browserIcon = UIImage(named: "safari.png")!
            var noteIcon = UIImage(named: "note.png")!
            var storeIcon = UIImage(named: "store.png")!
            var settingsIcon = UIImage(named: "settings.png")!
            var codeIcon = UIImage(named: "Code.png")!
            
            if pear == ""{
                fileExplorerIcon = UIImage(named: "finderApple.png")!
                browserIcon = UIImage(named: "safariApple.png")!
                noteIcon = UIImage(named: "noteApple.png")!
                storeIcon = UIImage(named: "storeApple.png")!
                settingsIcon = UIImage(named: "settingsApple.png")!
                codeIcon = UIImage(named: "CodeApple.png")!
            }
            
            let finders = createIcon(fileExplorerIcon, "File explorer")
            finders.setAssociatedView(newView: finder(), newViewText: "File explorer", newViewFrame: frame)
            
            let safari = createIcon(browserIcon, "Browser")
            safari.setAssociatedView(newView: webBrowser(), newViewText: "Browser", newViewFrame: frame)
            
            let notes = createIcon(noteIcon, "Note")
            notes.setAssociatedView(newView: note(), newViewText: "Note", newViewFrame: frame)
            
            
            let storew = createIcon(storeIcon, "Store")
            storew.setAssociatedView(newView: store(), newViewText: "Store", newViewFrame: frame)
            
            let settingsw = createIcon(settingsIcon, "Settings")
            settingsw.setAssociatedView(newView: settings(), newViewText: "Settings", newViewFrame: frame)
            
            let xcode = createIcon(codeIcon, "Code")
            xcode.setAssociatedView(newView: FakePlayGrund(), newViewText: "Code", newViewFrame: frame)
        
        for _ in 0...1{
            let finders = createIcon(fileExplorerIcon, "File explorer")
            finders.setAssociatedView(newView: finder(), newViewText: "File explorer", newViewFrame: frame)
            
            let safari = createIcon(browserIcon, "Browser")
            safari.setAssociatedView(newView: webBrowser(), newViewText: "Browser", newViewFrame: frame)
            
            let notes = createIcon(noteIcon, "Note")
            notes.setAssociatedView(newView: note(), newViewText: "Note", newViewFrame: frame)
            
            
            let storew = createIcon(storeIcon, "Store")
            storew.setAssociatedView(newView: store(), newViewText: "Store", newViewFrame: frame)
            
            let settingsw = createIcon(settingsIcon, "Settings")
            settingsw.setAssociatedView(newView: settings(), newViewText: "Settings", newViewFrame: frame)
            
            let xcode = createIcon(codeIcon, "Code")
            xcode.setAssociatedView(newView: FakePlayGrund(), newViewText: "Code", newViewFrame: frame)
         }
            
            alreadyAdded = true
        }
        
        dock = getDock()
        iconSide = Int(dock.frame.height) - 25
        
        self.view.addSubview(background)
        self.view.addSubview(dock)
        self.view.addSubview(menu)
        
        
        if buttons.count > 0 {
            var tempLabel = CGPoint(x: 10, y: menuDistance)
            for item in buttons{
                item.frame.origin = tempLabel
                
                if let menus = item.associated{
                    if((item.frame.origin.x) + (menus.frame.size.width)) >= self.view.frame.size.width {
                        menus.frame.origin.x = self.view.frame.width - (menus.frame.width)
                    }
                }

                
                tempLabel.x += item.frame.width
                
                menu.addSubview(item)
                
            }
        }
        
        if iconCollection.count > 0{
            var startDesktopIndex = 0
            let offset = CGFloat(iconSide + spacing)
            
            let limit = (dock.frame.origin.x + dock.frame.width - offset * 2)
            let border = self.view.frame.width - offset
            
            var tempIconPoint = CGPoint(x: 10 + dock.frame.origin.x ,y: 5 + dock.frame.origin.y)
            
            tempIconPoint.x -= offset
            
            
            var iconToKeep = [ButtonItem]()
            for i in 0...iconCollection.count - 1{
                let item = iconCollection[i]
                
                if tempIconPoint.x >= limit{
                    tempIconPoint.x = border
                    tempIconPoint.y = CGFloat(menuHeight + 7 + Int(offset) * (i - startDesktopIndex - 1))
                    
                    item.removeTarget(self, action: #selector(self.dockItemOpening(_:)), for: .touchUpInside)
                    
                    if item.imageView?.image != nil && item.titleLabel?.text != nil && item.associatedView != nil{
                        let file = createFile((item.imageView?.image)!, (item.titleLabel?.text)!)
                        //file.fileButton = item
                        //file.fileButton.associatedView = item.associatedView
                        
                        file.fileButton.setAssociatedView(newView: item.associatedView, newViewText: item.associatedView.textLabel.text!, newViewFrame: item.associatedView.view.frame)
                        
                        
                        //file.fileButton.associatedViewFrame = item.associatedViewFrame
                        
                        //file.backgroundColor = .white
                        //iconCollection.remove(at: i)
                    }
                    item.isHidden = true
                    
                }else{
                    
                    tempIconPoint.x += offset
                    
                    startDesktopIndex = i
                    
                    iconToKeep.append(item)
                }
                item.frame.size = CGSize(width: iconSide,height: iconSide)
                item.frame.origin = tempIconPoint
                
                //dock.addSubview(item)
                
                self.view.addSubview(item)
            }
            iconCollection = iconToKeep
        }
        
        if files.count > 0{
            let offset = CGFloat((iconSide + 20 + 20) + spacing)
            let border = self.view.frame.width - offset + 20 //+ CGFloat(spacing)
            
            var tempFilePoint = CGPoint(x: border, y: (CGFloat(menuHeight + spacing + menuDistance) - offset))
            for item in files{
                tempFilePoint.y += offset
                
                if tempFilePoint.y > dock.frame.origin.y - offset{
                    tempFilePoint.x -= offset - 20
                    tempFilePoint.y = CGFloat(menuHeight + spacing + menuDistance)
                }
                
                item.frame.origin = tempFilePoint
                
                self.view.addSubview(item)
            }
            
        }
        
        //currentView = self
        
        
        //background.addSubview(menu)
        
        
        //self.view.addSubview(BrowserViewController())
    }
    
    override public func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        checkDistance()
    }
    
    func setCurrentView(){
        if currentView == self{
            currentView.menuDistance = menuDistance
            currentView.view.frame = self.view.frame
        }
        
        /*if mainView != self{
            mainView.menuDistance = menuDistance
            mainView.view.frame = self.view.frame
        }*/
    }
    
    func checkDistance(){
        if onPlaygound == false{
            if UIDevice.current.userInterfaceIdiom == .phone {
                let orientattion = UIApplication.shared.statusBarOrientation
                if orientattion  == .landscapeRight || orientattion == .landscapeLeft{
                    menuDistance = 0
                }else{
                    menuDistance = 20
                }
                print("running on iphone interface")
            }else if UIDevice.current.userInterfaceIdiom == .pad{
                menuDistance = 20
                print("running on ipad interface")
            }else{
                print("running on unknown interface")
                menuDistance = 0
            }
        }else{
            menuDistance = 0
        }
        resetUI()
    }
    
    var i = 1
    @objc func melaMenuClick(_ sender: UIButton) {
        print(" \(i)")
        i += 1
    }
    
    @objc func menuButtonDidPress(_ sender: UIButton){
        sender.backgroundColor = menuBlu
        sender.setTitleColor(.white, for: .normal)
    }
    
    @objc func menuButtonDidUnpress(_ sender: UIButton){
        sender.backgroundColor = UIColor().withAlphaComponent(0)
        sender.setTitleColor(.black, for: .normal)
    }
    
    @objc func dockItemOpening(_ sender: UIButton){
        let delay = 0.45
        let offset = CGFloat(20)
        
        UIView.animate(withDuration: delay, delay: 0, options: .curveEaseInOut, animations: {
            sender.frame.origin.y -= offset
        }, completion: { finished in
            
        })
        UIView.animate(withDuration: delay, delay: delay, options: .curveEaseInOut, animations: {
            sender.frame.origin.y += offset
        }, completion: { finished in
            
        })
        
        
    }
    
    @objc func dockItemClose(_ sender: UIButton){
        
    }
    
    @objc func info(_ sender: menuButton){
        
        let infoWindow = ApplicationBar()
        let height = (Int(self.view.frame.height) - (menuHeight + 1 + menuDistance)) - Int(dock.frame.size.height) - 1
        let frame = CGRect(x: 0, y: menuHeight + 1 + menuDistance, width: Int(self.view.frame.width), height: height)
        
        infoWindow.view.frame = frame
        
        let title = UILabel()
        let body = UILabel()
        
        title.frame.origin.x = 0
        title.frame.origin.y = 40
        title.frame.size.width = frame.width
        title.frame.size.height = 50
        
        title.textAlignment = .center
        title.textColor = .black
        title.text = pear + "  playgroundOS"
        title.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[0], size: 40)
        
        body.frame.origin.x = 10
        body.frame.origin.y = title.frame.origin.y + title.frame.size.height
        body.frame.size.width = title.frame.size.width - 10
        body.frame.size.height = frame.height - body.frame.origin.y - 10
        
        body.font = UIFont(name: (UIFont.fontNames(forFamilyName: "Helvetica"))[1], size: 20)
        
        body.textAlignment = .left
        body.numberOfLines = 0
        body.text = "This playground is developed by Pietro Caruso 2017\n\nVersion 1.0"
        
        infoWindow.view.addSubview(title)
        infoWindow.view.addSubview(body)
        
        showViewController(infoWindow, frame)
    }
    
    @objc func procrastinate(_ sender: UIButton){
        openApplicationBar(window: procatinateWindow(), windowTitle: "Procrastinate")
    }
    
    @objc func showFinder(){
        openApplicationBar(window: finder(), windowTitle: "File explorer")
    }
    
    @objc func openSafari(){
        openApplicationBar(window: webBrowser(), windowTitle: "WebBrowser")
    }
    
    @objc func openNote(){
        openApplicationBar(window: note(), windowTitle: "Note")
    }
    
    @objc func openStore(){
        openApplicationBar(window: store(), windowTitle: "Store")
    }
    
    @objc func openSettings(){
        openApplicationBar(window: settings(), windowTitle: "Settings")
    }
    
    @objc func openCode(){
        openApplicationBar(window: FakePlayGrund(), windowTitle: "Code")
    }
    
    func openApplicationBar(window: ApplicationBar,windowTitle: String){
        let frame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7))
        window.textLabel.text = windowTitle
        showViewController(window, frame)
    }
    
    /*func openApplicationBarSetValue(window: ApplicationBar,windowTitle: String, value: Any?, forKey: String){
        let frame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7))
        window.textLabel.text = windowTitle
        window.setValue(value, forKey: forKey)
        showViewController(window, frame)
    }
    
    func openApplicationBarSetMultipleValues(window: ApplicationBar,windowTitle: String, values: [String: Any?]){
        let frame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7))
        window.textLabel.text = windowTitle
        
        for item in values{
            window.setValue(item.value, forKey: item.key)
        }
        
        showViewController(window, frame)
    }*/
    
    @objc func openApps(){
        let frame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7))
        let window = finder()
        
        window.textLabel.text = "File explorer"
        
        window.search.text = "C:\\Applications"
        
        showViewController(window, frame)
    }
    
    @objc func openRoot(){
        let frame = CGRect(x: 0, y: menuHeight + menuDistance + 7, width: Int(view.frame.width), height: Int(dock.frame.origin.y) - (menuHeight + menuDistance + 7))
        let window = finder()
        
        window.textLabel.text = "File explorer"
        
        window.search.text = "C:\\"
        
        showViewController(window, frame)
    }
    
    func profileImageHasBeenTapped(){
        currentStripMenu.hide()
    }
    
}

public class DesktopWithInitializerCustom: ViewController{
    public init(viewFrame: CGRect){
        super.init(nibName: nil, bundle: nil)
        
        self.view = UIView(frame: viewFrame)
        
        viewDidLoad()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

