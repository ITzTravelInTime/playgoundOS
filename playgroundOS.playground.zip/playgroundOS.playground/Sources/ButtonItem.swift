import Foundation
import UIKit

//button to open applications class
public class ButtonItem: UIButton{
    public var associatedView: ApplicationBar!
    public var parentController: ViewController!
    
    override public func reloadInputViews() {
        self.addTarget(self, action: #selector(self.openAssociated), for: .touchUpInside)
        
    }
    
    override public func didMoveToSuperview() {
        self.addTarget(self, action: #selector(self.openAssociated), for: .touchUpInside)
    }
    
    @objc func openAssociated(){
        print("called open associated: \(self.titleLabel?.text)")
        if associatedView != nil && parentController != nil{
            let p = parentController as ViewController
            
            let fr = CGRect(x: 0, y: p.menuHeight + p.menuDistance + 7, width: Int(p.view.frame.width), height: Int(p.dock.frame.origin.y) - (p.menuHeight + p.menuDistance + 7) )
            associatedView.tempSize = fr
            parentController.showViewController(associatedView, fr)
            associatedView.setNormalScreen()
            associatedView.textLabel.text = self.titleLabel?.text
            associatedView.view.isHidden = false
        }
    }
    
    public func setAssociatedView(newView: ApplicationBar, newViewText: String, newViewFrame: CGRect){
        self.associatedView = newView
        self.associatedView.textLabel.text = newViewText
        self.associatedView.view.frame = newViewFrame
    }
}
